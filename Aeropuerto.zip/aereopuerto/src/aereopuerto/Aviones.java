package aereopuerto;

public class Aviones {

	String modelo;
	String capacidad;


	public Aviones(String modelo, String capacidad) {
		this.modelo = modelo;
		this.capacidad = capacidad;
	}
	public Aviones() {
		this.modelo = "comercial";
		this.capacidad = "200";
	}


	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getCapacidad() {
		return capacidad;
	}
	public void setCapacidad(String capacidad) {
		this.capacidad = capacidad;
	}


	public void imprimir(){
		System.out.println("   --- AVION ---");
		System.out.println("el modelo del avion es: "+modelo);
		System.out.println("La capacidad es: "+capacidad);
	}
}
