package aereopuerto;



	public class Pasajeros extends Personas {
		String asiento;
		

		public Pasajeros(String nombre, String edad, String sexo, String asiento) {
			super(nombre, edad, sexo);
			this.asiento = asiento;
		}

		public Pasajeros() {
			this.asiento = "ticket";
		}

		public String getAsiento() {
			return asiento;
		}

		public void setAsiento(String asiento) {
			this.asiento = asiento;
		}

	}