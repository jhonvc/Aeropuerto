package aereopuerto;

import java.util.ArrayList;
import java.util.List;

public class Vuelos {

	String hora;
	Aereopuerto aeroP1, aeroP2 = new Aereopuerto();
	Aviones avion = new Aviones();
	Pilotos piloto1 = new Pilotos();
	List<Pasajeros> pasajero = new ArrayList<Pasajeros>();

	
	public Vuelos(String hora, Aereopuerto aeroP1, Aereopuerto aeroP2, Aviones avion, Pilotos piloto1,
			List<Pasajeros> pasajero) {
		super();
		this.hora = hora;
		this.aeroP1 = aeroP1;
		this.aeroP2 = aeroP2;
		this.avion = avion;
		this.piloto1 = piloto1;
		
		this.pasajero = pasajero;
	}

	

	public Vuelos() {
	}

	public void imprimir(){
		System.out.println("-------------- VUELO ------------------");
		System.out.println("La hora del vuelo es a: "+hora);
		System.out.println("Aeropuerto Origen: "+aeroP1.ciudad);
		System.out.println("Aeropuerto Destino: "+aeroP2.ciudad);
		avion.imprimir();
		System.out.println("Datos del Piloto: ");
		piloto1.imprimir();
		System.out.println("piloto1.edad");
		for (Pasajeros pasajero2 : pasajero) {
			pasajero2.imprimir();
		}
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public Aereopuerto getAeroP1() {
		return aeroP1;
	}

	public void setAeroP1(Aereopuerto aeroP1) {
		this.aeroP1 = aeroP1;
	}

	public Aereopuerto getAeroP2() {
		return aeroP2;
	}

	public void setAeroP2(Aereopuerto aeroP2) {
		this.aeroP2 = aeroP2;
	}

	public Aviones getAvion() {
		return avion;
	}

	public void setAvion(Aviones avion) {
		this.avion = avion;
	}

	public Pilotos getPiloto1() {
		return piloto1;
	}

	public void setPiloto1(Pilotos piloto1) {
		this.piloto1 = piloto1;
	}

	public List<Pasajeros> getPasajero() {
		return pasajero;
	}

	public void setPasajero(List<Pasajeros> pasajero) {
		this.pasajero = pasajero;
	}


}
