package aereopuerto;

public class Pasajero {

}
