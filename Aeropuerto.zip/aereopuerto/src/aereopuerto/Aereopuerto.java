package aereopuerto;

import java.util.ArrayList;
import java.util.List;

public  class Aereopuerto {

	String nombre;
	String ciudad;
	List<Vuelos> vuelo = new ArrayList<Vuelos>();

	public  Aereopuerto(String nombre, String ciudad) {
		super();
		this.nombre = nombre;
		this.ciudad = ciudad;
		
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public List<Vuelos> getVuelo() {
		return vuelo;
	}

	public void setVuelo(List<Vuelos> vuelo) {
		this.vuelo = vuelo;
	}

	public Aereopuerto() {
		this.nombre = "aeroNombre";
		this.ciudad = "aeroCiudad";
	}

	public void imprimir(){
		for (Vuelos vuelos : vuelo) {
			System.out.println("-------");
			for (Pasajeros pasajero : vuelos.pasajero) {
				pasajero.imprimir();
			}
		}
	}
}

