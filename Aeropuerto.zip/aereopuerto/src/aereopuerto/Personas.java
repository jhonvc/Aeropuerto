package aereopuerto;

public class Personas {

	String nombre;
	String edad;
	String sexo;
	public Personas(String nombre, String edad, String sexo) {

		this.nombre = nombre;
		this.edad = edad;
		this.sexo = sexo;
	}
	public Personas() {
		this.nombre = "nombre";
		this.edad = "18";
		this.sexo = "masculino";
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getEdad() {
		return edad;
	}
	public void setEdad(String edad) {
		this.edad = edad;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public void imprimir(){
		System.out.println("Nombre: "+nombre);
		System.out.println("Edad: "+edad);
		System.out.println("Sexo: "+sexo);
	}
}
