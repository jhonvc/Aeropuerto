package aereopuerto;

import java.util.ArrayList;
import java.util.List;

public class Main {



		public static void main(String[] args) {
			// TODO Auto-generated method stub
			List<Pasajeros> listadopasajero = new ArrayList<Pasajeros>();
			

			Aereopuerto ae1 = new Aereopuerto("Rodriguez Ballon","Peru");
			Aereopuerto ae2 = new Aereopuerto("Aeropuerto internacional el dorado","Colombia");

			Aviones avion = new Aviones();
			Pilotos piloto = new Pilotos();

			Pasajeros pas1= new Pasajeros( "pasajero1",  "50",  "femenino",  "1");
			
			
			Pasajeros pas2= new Pasajeros( "pasajero2",  "20",  "femenino",  "2");
			
			
			Pasajeros pas3= new Pasajeros( "pasajero3",  "31",  "femenino",  "3");
			
			listadopasajero.add(pas1);listadopasajero.add(pas2);listadopasajero.add(pas3);
			
			
			Vuelos v1=new Vuelos("22:20", ae1, ae2, avion, piloto, listadopasajero);
			
			
			v1.imprimir();
			
			
	

	}
}
