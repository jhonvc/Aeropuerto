package aereopuerto;

public class Pilotos extends Personas {



	private String licencia;

	public Pilotos(String licencia, String nombre, String edad, String sexo) {
		super(nombre, edad, sexo);
		this.licencia = licencia;
	}

	public Pilotos() {
		this.licencia = "dfa";
	}

	public String getLicencia() {
		return licencia;
	}

	public void setLicencia(String licencia) {
		this.licencia = licencia;
	}

}
